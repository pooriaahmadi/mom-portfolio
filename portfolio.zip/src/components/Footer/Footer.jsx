import "../../styles/footer/footer.scss";

const Footer = () => {
  return (
    <footer>
      <h2>Samira © 2023</h2>
    </footer>
  );
};

export default Footer;
